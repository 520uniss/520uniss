<?php
$type = $_GET['type'];
$page = isset($_GET['page']) ? $_GET['page'] : null;
switch ($type){
	case 'list':
		$name = $_GET['name'];
		switch($name){
			case '3':
				$typeId=3;
			break;
			case '2':
				$typeId=2;
			break;
			case '1':
				$typeId=1;
			break;
			case '4':
				$typeId=4;
			break;
			case '7':
				$typeId=7;
			break;
			case '6':
				$typeId=6;
			break;
			case '5':
				$typeId=5;
			break;
		}
		$url=get_curl("http://mobile.api.hunantv.com/list?userId=&order=0&types=all&pageCount={$page}&pageSize=30&typeId="{$typeId});
		$json =json_decode($url,true);
		foreach($json['data'] as $list){
			$data[] = ['vid'=>$list['videoId'],'title'=>$list['name'],'img'=>$list['image'],'stars'=>$list['desc'],'time'=>$list['publishTime'],'tag'=>$list['tag']];
		}
		echo json_encode(['result'=>1,'data'=>$data]);
	break; 
	case 'profile':
		$vid = $_GET['vid'];
		$url=get_curl("http://mobile.api.hunantv.com/v3/video/getVideoInfo?appVersion=4.5.2&osVersion=6.0.1&ticket=&osType=android&videoId="{$vid});
		$json =json_decode($url,true);
		echo json_encode(['result'=>1,"data"=>$json['data']['collectionDesc'],'title'=>$json['data']['collectionName'],'stars'=>$json['data']['player'],'director'=>$json['data']['director'],'publishTime'=>$json['data']['publishTime']]);
	break;
	case 'playlist':
		$vid = $_GET['vid'];
		$url = get_curl("http://mobile.api.hunantv.com/v2/video/getMultiplyList?userId;&uid=&pageCount=1&appVersion=4.6.9&videoId="{$vid});
		$json = json_decode($url,true);
		foreach($json['data'] as $list){
			$data[]=["vid"=>$list['videoId'],'name'=>$list['name'],'img'=>$list['image'],'desc'=>$list['desc']];
		}
		echo json_encode(['result'=>1,"data"=>$data]);
	break;
	case 'sou';
		$name = urlencode($_GET['name']);
		$url = file_get_contents("http://mobile.api.hunantv.com/v2/search/getResult?userId=&osVersion=4.4&name="{$name});
		$json = json_decode($url,true);
		foreach($json['data']['relatedVideo'] as $list){
			$data[] = ['vid'=>$list['videoId'],'cid'=>$list['cid'],'title'=>$list['name'],'img'=>$list['image'],'updateDesc'=>$list['updateDesc'],'descStr'=>$list['descStr'],'videoType'=>$list['videoType']];
		}
	echo json_encode(['result'=>1,"data"=>$data]);
	break;	
default:
	echo json_encode(['result'=>-1,"ErrorMsg"=>"参数错误"]);
}
function get_curl($url, $post = 0, $referer = 0, $cookie = 0, $header = 0, $ua = 0, $nobaody = 0){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    if ($post) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    if ($header) {
        curl_setopt($ch, CURLOPT_HEADER, TRUE);
    }
    if ($cookie) {
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    }
	if ($referer) {
		curl_setopt($ch, CURLOPT_REFERER, $referer);
	}else{
		curl_setopt($ch, CURLOPT_REFERER, $_SERVER['HTTP_HOST']);
	}
    if ($ua) {
        curl_setopt($ch, CURLOPT_USERAGENT, $ua);
    } else {
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 4.0.4; es-mx; HTC_One_X Build/IMM76D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0');
    }
    if ($nobaody) {
        curl_setopt($ch, CURLOPT_NOBODY, 1);
    }
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $ret = curl_exec($ch);
    curl_close($ch);
    return $ret;
}
?>