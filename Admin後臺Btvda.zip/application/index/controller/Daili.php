<?php
namespace app\index\controller;

use \think\Validate;
use think\Request;
use think\Db;
use think\Cookie;

class Daili extends Common
{
	function __construct()
    {
        parent::__construct();
        //判断是否已登录
		$username = Cookie::get("username","kyuser_");
		$password = Cookie::get("passwrod","kypwd_");
		if($username !== null){
			if(!$this->userInfo = Db::name('user')->where("user=:user and pwd=:pwd and daili=1")->bind(['user'=>$username,'pwd'=>$password])->find()){
				exit($this->error('请登陆',url('index/login')));
			}else{
				$this->user = $this->userInfo;
				$this->assign('user',$this->userInfo);
			}
        }else{
			exit($this->error('请登陆',url('index/login')));
		}
    }
    public function index()
    {
    	if(Request::instance()->isPost()){
    		$km = input('km');
    		if(!$km){
    			return alret("请输入卡密");
    		}else{
    			if($row=Db::name('km')->where("km=:km and kind=2 and sign=:sign")->bind(['km'=>$km,'sign'=>$this->user['sign']])->find()){
    				if(Db::name('user')->where('id',$this->user['id'])->update(['rmb'=>$this->user['rmb']+$row['value']])){
    					Db::name('km')->where('id',$row['id'])->update(['isuse'=>1,'user'=>$this->user['user'],'usetime'=>date("Y-m-d H:i:s")]);
    					return alret('充值成功');
    				}else{
    					return alret("充值失败");
    				}
    			}else{
    				return alret("卡密不存在");
    			}
    		}
    	}
    	$km = Db::name('km')->where("daili='".$this->user['id']."'")->count('id');
    	return View('index',[
    			'title'=>"代理中心",
    			'km'=>$km,
    		]);
    }
    public function kmlist()
    {
    	if(Request::instance()->isPost()){
    		$num = input('num');
    		$value = input('value');
    		if($this->user['rmb']<=0){
    			return alret("您的余额不足,请充值");
    		}
    		if($row=Db::name('tc')->where('id=:id and sign=:sign')->bind(['id'=>input('value'),'sign'=>$this->user['sign']])->find()){
    			$tcrmb=$num*$row['tcrmb'];
    			if($this->user['rmb']<=$tcrmb){
    				return alret("您的余额不足,请充值");
    			}
    			$kms="";
    			for($i=1;$i<=$num;$i++){
    				$km = get_sz();
					$data=['kind'=>1,'sign'=>$this->user['sign'],'daili'=>$this->user['id'],'km'=>$km,'value'=>$row['rmb'],'isuse'=>0,'addtime'=>date("Y-m-d")];
					Db::name('user')->where('id',$this->user['id'])->update(['rmb'=>$this->user['rmb']-$tcrmb]);
					if(Db::name('km')->insert($data)){
						$kms .= $km . '<br>';
					}else{
						return alret('生成失败');
					}
    			}
    			$this->assign('kms',$kms);
    		}else{
    			return alret("服务器内部出错");
    		}
    	}
   	$this->assign('tclist',Db::name('tc')->where('sign',$this->user['sign'])->select());
    $this->assign('list',Db::name('km')->where('daili',$this->user['id'])->paginate(10));
    return View('kmlist',[
    		'title'=>'卡密列表',
    	]);
    }
        public function uinfo()
    {
        if(Request::instance()->isPost()){
            if(!input('pass')){
                return alret("请输入密码");
            }
            if(input('pass')){
                $data = [
                    'pwd'=>md5(input("pass")."847257802"),
                    'email'=>input('eamil'),
                ];
            }else{
                $data = [
                    //'pwd'=>md5(input("pass")."847257802"),
                    'email'=>input('eamil'),
                ];
            }
            if(Db::name('user')->where('id',$this->user['id'])->update($data)){
                return alret('修改成功',url('/logout'));
            }else{
                return alret("修改失败");
            }
        }
        return View('uinfo',[
                'title'=>'修改用户',
            ]);
    }
}