<?php
namespace app\index\controller;

use \think\Validate;
use think\Request;
use think\Db;
use think\Cookie;

class Api extends Common{
	public function uset(){
		$user = input('user');
		$pass = input('pass');
		$cpass = input('cpass');
		$sign = input('sign');
		if(!$user || !$pass || !$cpass || !$sign){
			return json(['code'=>"-1001","ErrorMsg"=>"请输入完整"]);
		}else{
			$rule = [
				'user'  => 'require|max:20|min:5|chsAlphaNum',
				'pass'   => 'require|max:20|min:5|alphaNum',
				'cpass'	=> 'require|max:20|min:5|alphaNum',
				//'code'	=>	'require',
				'sign'	=>	'require',
			];
			$msg = [
				'user.require' => '请输入用户名',
				'user.chsAlphaNum' => '用户名只能数字,汉字,字母,不能出现特殊符号',
				'user.max'     => '用户名最多不能超过20个字符',
				'user.min'	   => '用户名不能小于5个字符',
				'pass.require'   => '请输入密码',
				'pass.alphaNum' => '密码只能字母,数字,不能出现特殊符号或汉字',
				'pass.max'  => '密码最多不能超过10个字符',
				'cpass.min'  => '密码不能小于5个字符',
				'cpass.require'   => '请输入密码',
				'cpass.alphaNum' => '密码只能字母,数字,不能出现特殊符号或汉字',
				'cpass.max'  => '密码最多不能超过10个字符',
				'cpass.min'  => '密码不能小于5个字符',
				'sign'	=>	'sign未输入',
			];
			$data = [
				'user'  => $user,
				'pass'   => $pass,
				'cpass'	=> $cpass,
			];
			$validate = new Validate($rule,$msg);
			$result   = $validate->check(input());
			if(!$result){
				return json(['code'=>"-1005","ErrorMsg"=>$validate->getError()]);
			}else{
				if ($row = Db::name("user")->where("user=:user and pwd=:pwd and sign=:sign")->bind(['user'=>input('user'),'pwd'=>md5(input('pass')."847257802"),'sign'=>input('sign')])->find()) {
					db('user')->where('id',$row['id'])->update(['pwd'=>md5($cpass.'847257802')]);
					return json(['code'=>"-1000","data"=>'修改成功:请重新登陆!']);
				}else{
					return json(['code'=>"-1001","ErrorMsg"=>"修改失败!原密码错误!"]);
				}
			}
		}
	}
	public function reg(){
		if(input("type")=='imei'){
		$imei = input("user");
		//$code = input("code");
		$sign = input('sign');
		if(!$imei || !$sign ){
			return json(['code'=>"-1001","ErrorMsg"=>"请输入完整"]);
		}else{
			if(!$row=Db::name("list")->where("appkey=:appkey")->bind(['appkey'=>input('sign')])->find()){
				return json(['code'=>"-1002","ErrorMsg"=>"sign错误"]);
			}elseif(Db::name("imei")->where("imei",$imei)->find()){
				return json(['code'=>"-1003","ErrorMsg"=>"imei存在"]);
			}else{
				$data=[
					'imei'=>$imei,
					'sign'=>$sign,
					'vip'=>0,
					'viptime'=>null,
					'regip'=>getip(),
					'addtime'=>date("Y-m-d H:i:s"),
				];
				if(Db::name("imei")->insert($data)){
					return json(['code'=>"-1000","data"=>'注册成功']);
				}else{
					return json(['code'=>"-1001","ErrorMsg"=>"注册失败"]);
				}
			}
		}
		}elseif(input("type")=='user'){
			$rule = [
				'user'  => 'require|max:20|min:5|chsAlphaNum',
				'pass'   => 'require|max:20|min:5|alphaNum',
				'qq' => 'require|number',
				//'code'	=>	'require',
				'sign'	=>	'require',
			];
			$msg = [
				'user.require' => '请输入用户名',
				'user.chsAlphaNum' => '用户名只能数字,汉字,字母,不能出现特殊符号',
				'user.max'     => '用户名最多不能超过20个字符',
				'user.min'	   => '用户名不能小于5个字符',
				'pass.require'   => '请输入密码',
				'pass.alphaNum' => '密码只能字母,数字,不能出现特殊符号或汉字',
				'pass.max'  => '密码最多不能超过10个字符',
				'pass.min'  => '密码不能小于5个字符',
				'qq.require'   => '请输入QQ',
				'qq.number'	   => 'QQ必须是数字',
				'sign'	=>	'sign未输入',
				//'code'	=>	'验证码未输入',
			];
			//$code = input("code");
			$validate = new Validate($rule,$msg);
			$result   = $validate->check(input());
			if(!$result){
				return json(['code'=>"-1005","ErrorMsg"=>$validate->getError()]);
			}else{
				if(isset($_SESSION['app_code'])){
					$app_code=$_SESSION['app_code'];
				}else{
					$app_code=null;
				}
				if(!$row=Db::name("list")->where("appkey=:appkey")->bind(['appkey'=>input('sign')])->find()){
					return json(['code'=>"-1004","ErrorMsg"=>"sign错误"]);
				}elseif(Db::name('user')->where("user=:user")->bind(['user'=>input('user')])->find()){
					return json(['code'=>"-1003","ErrorMsg"=>"用户名存在!"]);
				}else{
					$data=['user'=>input('user'),"daili"=>0,'pwd'=>md5(input('pass')."847257802"),"qq"=>input('qq'),"sign"=>input('sign'),"admin"=>0,"vip"=>0,"viptime"=>null,"regtime"=>date("Y-m-d H:i:s"),"regip"=>getip(),"addtime"=>date("Y-m-d H:i:s")];
					if(Db::name('user')->insert($data)){
						return json(['code'=>"-1000",'data'=>'注册成功!']);
					}else{
						return json(['code'=>"-1001",'ErrorMsg'=>'注册失败!请稍后再试!']);
					}
				}
				//unset($_SESSION['app_code']);//销毁
			}
		}
	}
	public function login(){
		if(input('type')=='imei'){
			$imei = input("user");
			$sign = input('sign');
			if(!$imei || !$sign){
				return json(['code'=>"-1001","ErrorMsg"=>"请输入完整"]);
			}else{
				if(!$row=Db::name("list")->where("appkey=:appkey")->bind(['appkey'=>input('sign')])->find()){
					return json(['code'=>"-1001","ErrorMsg"=>"sign错误!"]);
				}elseif(!$row=Db::name("imei")->where("imei=:imei and sign=:sign")->bind(['imei'=>$imei,"sign"=>$sign])->find()){
					return json(['code'=>"-1002","ErrorMsg"=>"登录失败!"]);
				}else{
					return json(['code'=>"-1000","data"=>"登陆成功!"]);
				}
			}
		}elseif(input('type')=='user'){
			$rule = [
				'user'  => 'require|max:20|min:5|chsAlphaNum',
				'pass'   => 'require|max:20|min:5|alphaNum',
				'sign'	=>	'require',
			];
			$msg = [
				'user.require' => '请输入用户名',
				'user.chsAlphaNum' => '用户名只能输入数字,汉字,字母,不能出现特殊符号',
				'user.max'     => '用户名最多不能超过20个字符',
				'user.min'	   => '用户名不能小于5个字符',
				'pass.require'   => '请输入密码',
				'pass.alphaNum' => '密码只能输入字母,数字,不能出现特殊符号或汉字',
				'pass.max'  => '密码最多不能超过20个字符',
				'pass.min'  => '密码不能小于5个字符',
				'sign'	=>	'sign未输入',
			];
			$validate = new Validate($rule,$msg);
			$result   = $validate->check(input());
			if(!$result){
				return json(['code'=>"-1002","ErrorMsg"=>$validate->getError()]);
			}else{
				if ($row = Db::name("user")->where("user=:user and pwd=:pwd and sign=:sign")->bind(['user'=>input('user'),'pwd'=>md5(input('pass')."847257802"),'sign'=>input('sign')])->find()) {
					if($row['viptime']<=date("Y-m-d H:i:s")){
						Db::name('user')->where("user",input('user'))->update(['vip'=>0]);
					} else{if($row['viptime']>=date("Y-m-d H:i:s")){
					    Db::name('user')->where("user",input('user'))->update(['vip'=>1]);
					} 
				}
					return json(['code'=>"-1000","data"=>"登陆成功!"]);
				}else{
					return json(['code'=>"-1001","ErrorMsg"=>"登陆失败!密码或用户名错误!"]);
				}
			}
		}
	}
	public function Getinfo($value=''){

		$sign = input("sign");
		if(!$sign){
			return json(['code'=>"-1001","ErrorMsg"=>"请输入完整"]);
		}elseif(!$info=Db::table("app_list")->where("appkey=:appkey")->bind(['appkey'=>$sign])->find()){
			return json(['code'=>"-1001","ErrorMsg"=>"APPKEY不存在"]);
		}else{		
			if(!$link=Db::table("app_api")->where("appid",$info['id'])->select()){
				return json(['code'=>"-1001","ErrorMsg"=>"没有接口"]);
			}else{
				foreach ($link as $value) {
					$data[] = [$value['name']=>rc4a($value['data'])];
				}
				return json(['code'=>"-1000","app_version"=>$info['ver'],"qunkey"=>$info['qunkey'],"url"=>$info['url'],"app_log"=>$info['update'],"tc"=>$info['tc'],"app_start"=>$info['text'],"data"=>$data]);
			}
			
		}
	}
	public function Getuser(){
		if(input("type")=='imei'){
			$imei = input("user");
			$sign = input('sign');
			if(!$imei || !$sign){
				return json(['code'=>"-1004","ErrorMsg"=>"请输入完整"]);
			}else{
				if(!$row=Db::name("list")->where("appkey=:appkey")->bind(['appkey'=>input('sign')])->find()){
					return json(['code'=>"-1003","ErrorMsg"=>"sign错误"]);
				}elseif(!$row=Db::name("imei")->where("imei=:imei and sign=:sign")->bind(['imei'=>$imei,"sign"=>$sign])->find()){
					return json(['code'=>"-1002","ErrorMsg"=>"未授权用户"]);
				}else{
					$time = substr($row['viptime'],0,4);
					if($time<2020){
						$viptime = $row['viptime'];
					}else{
						$viptime = "無敵永久會員";
					}
					if($row['viptime']<=date("Y-m-d H:i:s")){
						//Db::name('user')->where("user",input('user'))->update(['vip'=>0]);
					}else{
						Db::name('user')->where("user",$row['user'])->update(['vip'=>0]);
					}
					$zero1=strtotime (date("y-m-d h:i:s")); //当前时间  ,注意H 是24小时 h是12小时 
					$zero2=strtotime ($row['viptime']);  //过年时间，不能写2014-1-21 24:00:00  这样不对 
					$guonian=ceil(($zero2-$zero1)/86400); //60s*60min*24h   
					//echo "离过期还有<strong>$guonian</strong>天！";  
					if($guonian<=-0){
						$endtime='已过期';
					}else{
						$endtime=$guonian;  
					}
					if($row['viptime']<=date("Y-m-d H:i:s")){
						return json(['code'=>"-1001","imei"=>$row['imei'],"vip"=>$row['vip'],"viptime"=>$viptime,"endtime"=>$endtime]);
					}else{
						return json(['code'=>"-1000","imei"=>$row['imei'],"vip"=>$row['vip'],"viptime"=>$viptime,"endtime"=>$endtime]);
					}
				}
			}
		}elseif(input("type")=='user'){
			$rule=[
				'user'  => 'require|max:20|min:5|chsAlphaNum',
				'pass'   => 'require|max:20|min:5|alphaNum',
				'sign'	=>	'require',
			];
			$msg=[
				'user.require' => '请输入用户名',
				'user.chsAlphaNum' => '用户名只能数字,汉子,字母,不能出现特殊符号',
				'user.max'     => '用户名最多不能超过20个字符',
				'user.min'	   => '用户名不能小于5个字符',
				'pass.require'   => '请输入密码',
				'pass.alphaNum' => '密码只能字母,数字,不能出现特殊符号或汉子',
				'pass.max'  => '密码最多不能超过20个字符',
				'pass.min'  => '密码不能小于5个字符',
				'sign'	=>	'sign未输入',
			];
			$validate=new Validate($rule,$msg);
			$result=$validate->check(input());
			if(!$result){
				return json(['code'=>"-1002","ErrorMsg"=>$validate->getError()]);
			}else{
				if ($row=Db::name("user")->where("user=:user and pwd=:pwd and sign=:sign")->bind(['user'=>input('user'),'pwd'=>md5(input('pass')."847257802"),'sign'=>input('sign')])->find()) {
					if($row['viptime']<=date("Y-m-d H:i:s")){
						Db::name('user')->where("user",input('user'))->update(['vip'=>0]);
					} else{
						if($row['viptime']>=date("Y-m-d H:i:s")){	
					    Db::name('user')->where("user",input('user'))->update(['vip'=>1]);
					
					    }
					} 
					$time=substr($row['viptime'],0,4);
					if($time<2020){
						$viptime=$row['viptime'];
					}else{
						$viptime="無敵永久會員";
					}
					$zero1=strtotime (date("y-m-d h:i:s")); //当前时间  ,注意H 是24小时 h是12小时 
					$zero2=strtotime ($row['viptime']);  //过年时间，不能写2014-1-21 24:00:00  这样不对 
					$guonian=ceil(($zero2-$zero1)/86400); //60s*60min*24h   
					//echo "离过期还有<strong>$guonian</strong>天！";  
					if($guonian<=-0){
						$endtime='已过期';
					}else{
						$endtime=$guonian;  
					}
					return json(['code'=>"-1000","user"=>$row['user'],"qq"=>$row['qq'],"vip"=>$row['vip'],"daili"=>$row['daili'],"viptime"=>$viptime,"endtime"=>$endtime]);
				}else{
					return json(['code'=>"-1001","ErrorMsg"=>"错误!获取数据失败"]);
				}
			}
		}
	}
	public function Getlb(){
		$sign = input("sign");
		if(!$sign){
			return json(['code'=>"-1001","ErrorMsg"=>"请输入完整"]);
		}elseif(!$info=Db::table("app_list")->where("appkey=:appkey")->bind(['appkey'=>$sign])->find()){
			return json(['code'=>"-1001","ErrorMsg"=>"APPKEY不存在"]);
		}else{		
			if(!$link=Db::table("app_lb")->where("appid",$info['id'])->select()){
				return json(['code'=>"-1001","ErrorMsg"=>"没有轮播广告"]);
			}else{
				foreach ($link as $value) {
					$data[] = ["Tu"=>$value['url'],"Lx"=>$value['qq'],"Fs"=>$value['lx'],"Tj"=>$value['tj']];
				}
				return json(['code'=>"-1000","data"=>$data]);
			}
		}
	}
	public function shop(){
		if(input('type')=='imei'){
			$user = input("user");
			$km = input('km');
			$sign = input('sign');
			if(!$user || !$km || !$sign){
				return json(['code'=>"-1001","ErrorMsg"=>"请输入完整"]);
			}elseif(!$info=Db::table("app_list")->where("appkey=:appkey")->bind(['appkey'=>$sign])->find()){
				return json(['code'=>"-1002","ErrorMsg"=>"APPKEY不存在"]);
			}else{
			if($kms = Db::name("km")->where('km=:km and kind=1 and sign=:sign')->bind(['km'=>$km,"sign"=>$sign])->find()){
				if ($row = Db::name("imei")->where("imei=:imei  and sign=:sign")->bind(['imei'=>input('user'),'sign'=>input('sign')])->find()) {
					
						if($kms['isuse']==1){
							return json(['code'=>"-1003","ErrorMsg"=>"该卡密已被使用!"]);
						}else{
							$ms = $kms['value'];
							if($row['vip']==1){
								$data=[
									'viptime'=>date("Y-m-d", strtotime("+ {$ms} months", strtotime($row['viptime']))),
								];
								$msg = "续费成功!";
							}else{
								$data=[
									'vip'=>1,
									'viptime'=>$vipend = date("Y-m-d", strtotime("+ {$ms} months")),
								];
								$msg = "充值成功!";
							}
							if(Db::name('imei')->where('imei',$user)->update($data)){
								Db::name("km")->where("id",$kms['id'])->update(['isuse'=>1,"user"=>$user,"usetime"=>date("Y-m-d H:i:s")]);
								return json(['code'=>"-1004","data"=>$msg]);
							}else{
								return json(['code'=>"-1008","ErrorMsg"=>"充值失败!"]);
							}
						}
				}else{
					//return json(['code'=>"-1007","ErrorMsg"=>"登陆失败"]);
					$ms = $kms['value'];
					$data=[
						'imei'=>$user,
						'sign'=>$sign,
						'vip'=>1,
						'viptime'=>$vipend = date("Y-m-d", strtotime("+ {$ms} months")),
						'regip'=>getip(),
						'addtime'=>date("Y-m-d H:i:s"),
					];
					if(Db::name("imei")->insert($data)){
						Db::name("km")->where("id",$kms['id'])->update(['isuse'=>1,"user"=>$user,"usetime"=>date("Y-m-d H:i:s")]);
						return json(['code'=>"-1004","data"=>"充值成功!"]);
					}else{
						return json(['code'=>"-1007","ErrorMsg"=>"登陆失败!"]);
					}
				}
			}else{
				return json(['code'=>"-1006","ErrorMsg"=>"卡密不存在!"]);
			}
			}
		}elseif(input('type')=='user'){
			$user = input("user");
			$pass = input('pass');
			$km = input('km');
			$sign = input('sign');
			if(!$user || !$pass || !$km || !$sign){
				return json(['code'=>"-1001","ErrorMsg"=>"请输入完整"]);
			}elseif(!$info=Db::table("app_list")->where("appkey=:appkey")->bind(['appkey'=>$sign])->find()){
				return json(['code'=>"-1001","ErrorMsg"=>"APPKEY不存在"]);
			}else{
				if ($row = Db::name("user")->where("user=:user and pwd=:pwd and sign=:sign")->bind(['user'=>input('user'),'pwd'=>md5(input('pass')."847257802"),'sign'=>input('sign')])->find()) {
					if($kms = Db::name("km")->where('km=:km and kind=1 and sign=:sign')->bind(['km'=>$km,"sign"=>$sign])->find()){
						if($kms['isuse']==1){
							return json(['code'=>"-1002","ErrorMsg"=>"卡密已被使用!"]);
						}else{
							$ms = $kms['value'];
							if($row['vip']==1){
								$data=[
									'viptime'=>date("Y-m-d H:i:s", strtotime("+ {$ms} months", strtotime($row['viptime']))),
								];
								$msg = "續費成功!";
							}else{
								$data=[
									'vip'=>1,
									'viptime'=>$vipend = date("Y-m-d H:i:s", strtotime("+ {$ms} months")),
								];
								$msg = "充值成功!";
							}
							if(Db::name('user')->where('user',$user)->update($data)){
								Db::name("km")->where("id",$kms['id'])->update(['isuse'=>1,"user"=>$user,"usetime"=>date("Y-m-d H:i:s")]);
								return json(['code'=>"-1003","data"=>$msg]);
							}else{
								return json(['code'=>"-1007","ErrorMsg"=>"充值失敗!"]);
							}
						}
					}else{
						return json(['code'=>"-1008","ErrorMsg"=>"兌換碼錯誤,請檢查是否正確!!!"]);
					}
				}else{
					return json(['code'=>"-1009","ErrorMsg"=>"登陸失敗!"]);
				}
			}
		}
	}
}