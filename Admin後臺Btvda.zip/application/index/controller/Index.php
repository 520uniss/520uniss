<?php
namespace app\index\controller;

use \think\Validate;
use think\Request;
use think\Db;
use think\Cookie;

class Index extends Common
{
    public function index()
    {
        return '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0023)http://api.cccyou.cn.cn/## -->
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>神神云端系统</title>
<meta name="keywords" content="神神云端系统">
<meta name="description" content="神神云端系统">

<style type="text/css">
*{margin:0; padding:0;}
html,body{ width:100%; height:100%; position:relative;}
body{ font-family:\'微软雅黑\',\'黑体\',\'宋体\';background:#e8656e;}
.wrap{ width:600px;text-align:center;color:#fff; position:absolute; left:50%; top:50%; height:328px; margin:-164px 0 0 -300px;}
.wrap h1{ font-size:108px; font-weight:normal;}
.wrap h2{ font-size:34px; font-weight:normal;}
.wrap .easy{ width:505px; position:relative; border-top:1px solid #fff; display:inline-block; margin-top:20px;}
.easy span{ display:inline-block; height:27px; line-height:27px; padding:0 30px; font-size:20px; position:absolute; top:-15px; left:50%; background:#e8656e; margin-left:-66px;}
.wrap .enter{ display:inline-block; width:180px; height:35px; border:1px solid #fff; text-align:center; line-height:35px; color:#fff; font-size:20px; margin-top:90px; text-decoration:none;}
</style>
<style>#BAIDU_DSPUI_FLOWBAR,.adsbygoogle,.ad,div[class^="ad-widsget"],div[id^="div-gpt-ad-"]{display:none !important;}</style></head>

<body>
<div class="wrap">
  <h2>神神云端系统</h2>
  <h1>API</h1>
  <div class="easy"><span>23 GB/49.9 GB</span></div>
  <a href="../index/index/login.html" class="enter">神神云端系统</a>
</div>



</body></html>';
    }
	public function login(){
		if(Request::instance()->isPost()){
			$rule = [
				'user'  => 'require|max:10|min:5|chsAlphaNum',
				'pass'   => 'require|max:10|min:5|alphaNum',
			];
			$msg = [
				'user.require' => '请输入用户名',
				'user.chsAlphaNum' => '用户名只能数字,汉子,字母,不能出现特殊符号',
				'user.max'     => '用户名最多不能超过10个字符',
				'user.min'	   => '用户名不能小于5个字符',
				'pass.require'   => '请输入密码',
				'pass.alphaNum' => '密码只能字母,数字,不能出现特殊符号或汉子',
				'pass.max'  => '密码最多不能超过10个字符',
				'pass.min'  => '密码不能小于5个字符',
			];
			$validate = new Validate($rule,$msg);
			$result   = $validate->check(input());
			if(!$result){
				return alret($validate->getError());
			}else{
				if($row=Db::name("user")->where("user=:user and pwd=:pwd and (daili=1 or admin=1)")->bind(['user'=>input("user"),"pwd"=>md5(input("pass")."847257802")])->find()){
					Cookie::set('username',$row['user'],['prefix'=>'kyuser_','path'=>'/','expire'=>3600*24*7]);
					Cookie::set('passwrod',$row['pwd'],['prefix'=>'kypwd_','path'=>'/','expire'=>3600*24*7]);
					if($row['admin']==1){
						return alret("登陆成功",url("user/index"));
					}else{
						return alret("登陆成功",url('daili/index'));
					}
				}else{
					return alret("登陆失败:账号或密码错误");
				}
			}
		}
		return View("login");
	}
	public function cs(){
		return md5("神神");
	}
	public function logout()
	{
		Cookie::clear('kyuser_');
		Cookie::clear('kypwd_');
		return alret("退出成功",url('/index'));
	}
}
