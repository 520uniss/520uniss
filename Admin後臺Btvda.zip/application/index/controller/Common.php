<?php
namespace app\index\controller;

use think\Request;
use think\Db;
use think\Cookie;

class Common extends \think\Controller
{
	function __construct()
    {
        parent::__construct();
		
		config(Db::name('web')->where("id=:id")->bind(['id'=>1])->find());
	}
}
?>