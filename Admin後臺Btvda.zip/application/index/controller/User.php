<?php
namespace app\index\controller;

use \think\Validate;
use think\Request;
use think\Db;
use think\Cookie;

class User extends Common
{
	function __construct()
    {
        parent::__construct();
        //判断是否已登录
		$username = Cookie::get("username","kyuser_");
		$password = Cookie::get("passwrod","kypwd_");
		if($username !== null){
			if(!$this->userInfo = Db::name('user')->where("user=:user and pwd=:pwd and admin=1")->bind(['user'=>$username,'pwd'=>$password])->find()){
				exit($this->error('请登陆',url('index/login')));
			}else{
				$this->user = $this->userInfo;
				$this->assign('user',$this->userInfo);
			}
        }else{
			exit($this->error('请登陆',url('index/login')));
		}
    }
	public function index()
	{
		return View("index",[
				'title'=>"用户中心",
				'dl'=>Db::name('user')->where("daili=1")->count('id'),
				'dlkm'=>Db::name('km')->where("1=1")->count('id'),
				'user'=>Db::name('user')->where("1=1")->count("id"),
				'vip'=>Db::name('user')->where("vip=1")->count("id"),
				'km'=>Db::name('km')->where("1=1")->count('id'),
				'tc'=>Db::name('tc')->where('1=1')->count("id"),
			]);
	}
	public function add()
	{
		if(Request::instance()->isPost()){
			if(Db::name("list")->where("name=:name")->bind(['name'=>input("name")])->find()){
				return alret("用户名存在");
			}else{
				$data=[
					'name'=>input('name'),
					'appkey'=>input('appkey'),
					'ver'=>input('ver'),
					'qunkey'=>input('qunkey'),
					'url'=>input('url'),
					'gg'=>input('gg'),
					'tc'=>input('tc'),
					'text'=>input('text'),
					'update'=>input('update'),
					'time'=>date("Y-m-d H:i:s"),
				];
				if(Db::name("list")->insert($data)){
					return alret("添加成功",url('add'));
				}else{
					return alret("添加失败");
				}
			}
		}
		return View("add",[
				'title'=>'添加APP',
			]);
	}
	public function applist()
	{
		if(input("id")){
			Db::name('list')->where("id",input("id"))->delete();
			return alret("删除成功",url("applist"));
		}
		if(input("kw")){
			$list = Db::name("list")->where("name like '%".input('kw')."%'")->paginate(10);
		}else{
			$list = Db::name("list")->paginate(10);
		}
		$this->assign('list', $list);
		$this->assign('title','APP列表');
		return $this->fetch();
	}
	public function appset()
	{
		if(!input("id")){
			return $this->error("非法操作",url("index"));
		}
		if(Request::instance()->isPost()){
			$data=[
				'appkey'=>input('appkey'),
				'ver'=>input("ver"),
				'qunkey'=>input("qunkey"),
				'url'=>input('url'),
				'update'=>input('update'),
				'tc'=>input('tc'),
				'text'=>input('text'),
                 'time'=>date("Y-m-d H:i:s"),
			];
			if(Db::name("list")->where("id",input("id"))->update($data)){
				return alret("修改成功",url('applist'));
			}else{
				return alret("修改失败");
			}
		}
		$this->assign("row",Db::name("list")->where("id",input("id"))->find());
		return View('appset',[
				'title'=>"修改APP",
				'id'=>input("id"),
			]);
	}
	public function addlb()
	{
		if(input("id")){
			Db::name('lb')->where("id",input("id"))->delete();
			return alret("删除成功",url("addlb"));
		}
		if(Request::instance()->isPost()){
			$data=[
				'appid'=>input("app"),
				'lx'=>input('lx'),
				'url'=>input('url'),
				'qq'=>input('qq'),
				'tj'=>input('tj'),
				'dqtiem'=>input('dqtiem'),
				'time'=>date("Y-m-d H:i:s"),
			];
			if(Db::name("lb")->insert($data)){
				return alret("添加成功");
			}else{
				return alret("添加失败");
			}
		}
		$this->assign('app',Db::table("app_list")->where("1=1")->select());
		$list = Db::name("lb")->paginate(10);
		$this->assign('list', $list);
		return View("addlb",[
				'title'=>"轮播列表",
			]);
	}
	public function lbset(){
		if(!input("id")){
			return $this->error("非法操作",url("index"));
		}
		if(Request::instance()->isPost()){
			$data=[
				'appid'=>input("app"),
				'lx'=>input('lx'),
				'url'=>input('url'),
				'qq'=>input('qq'),
				'tj'=>input('tj'),
				'dqtiem'=>input('dqtiem'),
			];
			if(Db::name('lb')->where('id',input('id'))->update($data)){
				return alret("修改成功",url('addlb'));
			}else{
				return alret("修改失败");
			}
		}
		$this->assign('app',Db::table("app_list")->where("1=1")->select());
		$this->assign("rs",Db::name("lb")->where("id",input("id"))->find());
		return View("lbset",[
				'title'=>"轮播修改",
				'id'=>input("id"),
			]);
	}
	public function api()
	{
		if(input("id")){
			Db::name('api')->where("id",input("id"))->delete();
			return alret("删除成功",url("api"));
		}
		if(Request::instance()->isPost()){
			$data=[
				'appid'=>input("app"),
				'apiname'=>input("apiname"),
				'name'=>input("name"),
				'data'=>input('url'),
				'time'=>date("Y-m-d H:i:s"),
			];
			if(Db::name('api')->insert($data)){
				return alret("添加成功",url("api"));
			}else{
				return alret("添加失败");
			}
		}
		$this->assign('app',Db::table("app_list")->where("1=1")->select());
		$this->assign("list",Db::name('api')->paginate(15));
		return View('api',[
				'title'=>"API列表",
			]);
	}
	public function apiset()
	{
		if(!input("id")){
			return $this->error("非法操作",url("index"));
		}
		if(Request::instance()->isPost()){
			$data=[
				'appid'=>input("app"),
				'apiname'=>input('apiname'),
				'name'=>input('name'),
				'data'=>input('url'),
			];
			if(Db::name('api')->where('id',input('id'))->update($data)){
				return alret("修改成功",url('api'));
			}else{
				return alret("修改失败");
			}
		}
		$this->assign('app',Db::table("app_list")->where("1=1")->select());
		$this->assign("rs",Db::name("api")->where("id",input("id"))->find());
		return View("apiset",[
				'title'=>"API修改",
				'id'=>input("id"),
			]);
	}
	public function adduser()
	{
		if(Request::instance()->isPost()){
			if(Db::name("user")->where("user=:user")->bind(['user'=>input('user')])->find()){
				return alret("用户名存在",url("index"));
			}else{
				$sign = sign(input('app'));
				$data=['user'=>input('user'),"daili"=>input('daili'),'pwd'=>md5(input('pass')."847257802"),"qq"=>input('qq'),"sign"=>$sign,"admin"=>0,"vip"=>0,"viptime"=>null,"regtime"=>date("Y-m-d H:i:s"),"regip"=>getip(),"addtime"=>date("Y-m-d H:i:s")];
				if(Db::name('user')->insert($data)){
					return alret('添加成功');
				}else{
					return alret('添加失败');
				}
			}
		}
		$this->assign('app',Db::table("app_list")->where("1=1")->select());
		return View('adduser',[
				'title'=>"添加用户",
			]);
	}
	public function ulist()
	{
		if(input("type")=='dl'){
			$id = input("id");
			$row = Db::name("user")->where('id',$id)->find();
			if($row['daili']==1){
				Db::name("user")->where("id",$id)->update(['daili'=>0]);
			}else{
				Db::name("user")->where("id",$id)->update(['daili'=>1]);
			}
			return alret("设置成功",url('ulist'));
		}
		if(input("type")=='dell'){
			Db::name('user')->where("id",input("id"))->delete();
			return alret("删除成功",url("ulist"));
		}
		if(input("kw")){
			$list = Db::name("user")->where("user like '%".input('kw')."%'")->paginate(10);
		}else{
			$list = Db::name("user")->paginate(10);
		}
		$this->assign('list', $list);
		return View("ulist",[
				'title'=>'用户列表',
			]);
	}
	public function uset()
	{
		if(!input("id")){
			return $this->error("非法操作",url("index"));
		}
		if(Request::instance()->isPost()){
			if(input('pass')){
				$data=[
					'daili'=>input('daili'),
					'pwd'=>md5(input('pass')."847257802"),
					'qq'=>input('qq'),
				];
			}else{
				$data=[
					'daili'=>input('daili'),
					//'pwd'=>md5(input('pass')."847257802"),
					'qq'=>input('qq'),
				];
			}
			if(Db::name('user')->where('id',input("id"))->update($data)){
				return alret("修改成功",url('ulist'));
			}else{
				return alret("修改失败",url('ulist'));
			}
		}
		$this->assign('rs',Db::name('user')->where('id',input('id'))->find());
		return View('uset',[
				'title'=>'修改用户',
				'id'=>input('id'),
			]);
	}
	public function dlist()
	{
		if(input("type")=='dl'){
			$id = input("id");
			Db::name("user")->where("id",$id)->update(['daili'=>0]);
			return alret("设置成功",url('dlist'));
		}
		if(input("kw")){
			$list = Db::name("user")->where("user like '%".input('kw')."%'")->paginate(10);
		}else{
			$list = Db::name("user")->where('daili',1)->paginate(10);
		}
		$this->assign('list', $list);
		return View("dlist",[
				'title'=>'代理列表',
			]);
	}
	public function kmlist()
	{
		if(input("id")){
			Db::name('km')->where("id",input("id"))->delete();
			return alret("删除成功",url("kmlist"));
		}
		if(Request::instance()->isPost()){
			$lx = input('lx');
			$num = input('num');
			$value = input('value');
			if(!$num || !$value){
				return alret('请填写完整');
			}else{
				$kms = '';
				for($i = 0;$i < $num;$i++){
					$km = get_sz();
					$data=['kind'=>$lx,'sign'=>input('sign'),'daili'=>$this->user['id'],'km'=>$km,'value'=>$value,'isuse'=>0,'addtime'=>date("Y-m-d")];
					if(Db::name('km')->insert($data)){
						$kms .= $km . '<br>';
					}else{
						return alret('生成失败');
					}
				}
               
				$this->assign('kms', $kms);
			}
		}
		$list = Db::name('km')->where('1=1')->paginate(10);
		$this->assign('list', $list);
		$this->assign('title','卡密列表');
		$this->assign('app',Db::table("app_list")->where("1=1")->select());
		return View();
	}
	public function webset(){
		if(Request::instance()->isPost()){
			$data=[
				'title'=>input('title'),
				'keywords'=>input('keywords'),
				'description'=>input('description'),
				'qq'=>input('qq'),
				'text'=>input('text'),
			];
			if(Db::name('web')->where("id",1)->update($data)){
				return alret("修改成功");
			}else{
				return alret("修改失败");
			}
		}
		$this->assign("title","网站设置");
		return View();
	}
	public function tc()
	{
		if(input("id")){
			Db::name('tc')->where("id",input("id"))->delete();
			return alret("删除成功",url("tc"));
		}
		if(Request::instance()->isPost()){
			if(Db::name('tc')->where('name',input('name'))->find()){
				return alret("套餐存在");
			}else{
				$data = [
					'name'=>input('name'),
					'sign'=>input('app'),
					'rmb'=>input("rmb"),
					'tcrmb'=>input("tcrmb"),
				];
				if(Db::name('tc')->insert($data)){
					return alret("添加成功");
				}else{
					return alret("添加失败");
				}
			}
		}
		return view('tc',[
				'title'=>'套餐管理',
				'app'=>Db::name('list')->select(),
				'list'=>Db::name('tc')->paginate(10),
			]);
	}
	public function uinfo()
	{
		if(Request::instance()->isPost()){
			if(!input('pass')){
				return alret("请输入密码");
			}
			$data = [
				'pwd'=>md5(input("pass")."847257802"),
			];
			if(Db::name('user')->where('id',$this->user['id'])->update($data)){
				return alret('修改成功',url('/logout'));
			}else{
				return alret("修改失败");
			}
		}
		return View('uinfo',[
				'title'=>'修改用户',
			]);
	}
	public function imei()
	{
		if(input("id")){
			Db::name('imei')->where("id",input("id"))->delete();
			return alret("删除成功",url("imei"));
		}
		if(input("kw")){
			$list = Db::name("imei")->where("imei like '%".input('kw')."%'")->paginate(10);
		}else{
			$list = Db::name("imei")->paginate(10);
		}
		$this->assign('list', $list);
		return View("imei",[
				'title'=>'单码列表',
			]);
	}
}