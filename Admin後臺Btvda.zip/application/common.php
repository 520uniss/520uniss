<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件
function getIP(){
$ip = $_SERVER['REMOTE_ADDR'];
if (isset($_SERVER['HTTP_CF_CONNECTING_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_CF_CONNECTING_IP'])) {
	$ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
} elseif (isset($_SERVER['HTTP_CLIENT_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_CLIENT_IP'])) {
	$ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif(isset($_SERVER['HTTP_X_FORWARDED_FOR']) && preg_match_all('#\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}#s', $_SERVER['HTTP_X_FORWARDED_FOR'], $matches)) {
	foreach ($matches[0] AS $xip) {
		if (!preg_match('#^(10|172\.16|192\.168)\.#', $xip)) {
			$ip = $xip;
			break;
		}
	}
}
return $ip;
}
function alret($msg,$do=0){
	if($do==1){
		$alert="<script language='javascript'>alert('{$msg}');</script>";
		return $alert;
	}elseif($do){
		exit("<script language='javascript'>alert('{$msg}');window.location.href='".$do."';</script>");
	}else{
		exit("<script language='javascript'>alert('{$msg}');history.go(-1);</script>");
	}
}
function getapp($value){
	$row = db('list')->where("id=:id")->bind(['id'=>$value])->find();
	return $row['name'];
}
function sign($value){
	$row = db('list')->where("id=:id")->bind(['id'=>$value])->find();
	return $row['appkey'];
}
function app($value){
	$row = db('list')->where("appkey=:appkey")->bind(['appkey'=>$value])->find();
	return $row['name'];
}
function get_sz($len = 12)
{
    $str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    $strlen = strlen($str);
    $randstr = '';
    for ($i = 0; $i < $len; $i++) {
        $randstr .= $str[mt_rand(0, $strlen - 1)];
    }
    return $randstr;
}
function getkm($value){
	$row = db('user')->where("id=:id")->bind(['id'=>$value])->find();
	return $row['user'];
}

function rc4 ($pwd, $data){

     $key[] ="";

     $box[] ="";  

     $pwd_length = strlen($pwd);

     $data_length = strlen($data);  

     for ($i = 0; $i < 256; $i++) {

      $key[$i] = ord($pwd[$i % $pwd_length]);

      $box[$i] = $i;

     }  

     for ($j = $i = 0; $i < 256; $i++) {

      $j = ($j + $box[$i] + $key[$i]) % 256;

      $tmp = $box[$i];

      $box[$i] = $box[$j];

      $box[$j] = $tmp;

     }  

     for ($a = $j = $i = 0; $i < $data_length; $i++) {

      $a = ($a + 1) % 256;

      $j = ($j + $box[$a]) % 256;  

      $tmp = $box[$a];

      $box[$a] = $box[$j];

      $box[$j] = $tmp;  

      $k = $box[(($box[$a] + $box[$j]) %256)];

      @$cipher .= chr(ord($data[$i]) ^ $k);  

 }  
 return $cipher;  

}
  
function   hexToStr($hex){
      $string="";   
      for   ($i=0;$i<strlen($hex)-1;$i+=2)   
      $string.=chr(hexdec($hex[$i].$hex[$i+1]));   
      return   $string;   
}
function strToHex($string){
      return bin2hex($string);

}
 function rc4a($string){
return strToHex(rc4("Mr520Ss",$string));
}
function rc4b($string){
return  @rc4("Mr520Ss",pack('H*',$string));
}