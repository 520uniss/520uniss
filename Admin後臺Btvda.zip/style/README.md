Documentation: 
Read the "default/documentation.html" or "topbar/documentation.html"